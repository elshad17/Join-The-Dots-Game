import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class Username extends JPanel{
   //Variables
   HelpfulMethods info;
   int id;
   Player player;
   String name;
   JButton retrn;
   JLabel username,press,titleLabel;
   JTextField usernameField;
   ImageIcon img = new ImageIcon("back.jpg");
   ImageIcon returnIcon;
   
   //Consrtuctor
   public Username(HelpfulMethods info){
      this.info = info;
      createComponents();
      addComponents();
      
   }
   //creating components
   public void createComponents(){
      
      
      username = new JLabel("USERNAME");
      username.setBounds(300,200,170,60);
      username.setFont(new Font("Arial Black", Font.PLAIN, 24));
      
      usernameField = new JTextField();
      usernameField.setBounds(500,210,170,40);
      usernameField.addKeyListener(new EnterListener());
      
      
      
      titleLabel = new JLabel("JOIN THE DOTS");
      titleLabel.setFont(new Font("Arial Black", Font.PLAIN, 36));
      titleLabel.setBounds(380,20,600,50);
      
      returnIcon = new ImageIcon("return1.png");
      retrn = new JButton(returnIcon);
      retrn.setBounds(910,490,50,50);
      retrn.setBackground(Color.BLUE);
      retrn.addActionListener(new UsernameListener());
      
      
   }
   //adding components
   public void addComponents(){
      
      
      setLayout(null);
      
      add(username);
      add(usernameField);
      add(titleLabel);
      add(retrn);
      repaint();
      
      
      
   }
   
   /**
    * This method gets the players name.
    *@return name is the players name
    */
   public String getName(){
      return name;
      
   }
   
   /**
    * This method sets the players name.
    */
   public void setName(String name){
      
      this.name = name;
   }
   
  /**
    * This method draws image to panel
    *@param g is the graphics 
    */
   public void paintComponent(Graphics g) {
      
      g.drawImage(img.getImage(), 0, 0, null);
      
   }
   //EnterListener
   private class EnterListener implements KeyListener{
      
      public void keyPressed(KeyEvent evt){
         if(evt.getKeyCode() == KeyEvent.VK_ENTER) {
            setName(usernameField.getText());
            player = info.loginPlayer(usernameField.getText());
            id = player.getplayerID();
            //System.out.println(name);
            
            MenuPanel panel = new MenuPanel(info,id);
            panel.setBounds(0,0,1000,600);
            removeAll();
            
            add(panel);
            repaint();
            
         }
         
      }
      public void keyTyped(KeyEvent evt){
         
      }
      
      public void keyReleased(KeyEvent evt) {
         
      }
      
      
   }
   
   //Username listener
   private class UsernameListener implements ActionListener{
      
      public void actionPerformed(ActionEvent e){
         
         
         
         if(e.getSource()==retrn){
            
            try {
               UserFile userfile = new UserFile();
               userfile.listToFile(info.getallPlayers());
               
               
               Intro panel = new Intro();
               panel.setBounds(0,0,1000,600);
               removeAll();
               
               add(panel);
               repaint();
               
            }
            catch( IOException except ) {
               
               System.out.println("could not write to the file");
            }   
         }
      }  
   } 
}