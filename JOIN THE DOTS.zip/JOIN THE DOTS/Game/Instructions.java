import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class Instructions extends JPanel{
   
   //Variables
   HelpfulMethods info;
   int id;
   Player player;
   String name;
   JButton retrn;
   JLabel back,titleLabel;
   ImageIcon img = new ImageIcon("back.jpg");
   ImageIcon returnIcon, backIcon;
   
   
   //Constructor
   public Instructions(){
      
      createComponents();
      addComponents();
      
   }
   //Create components
   public void createComponents(){
      
      backIcon = new ImageIcon("backss.jpg");
      back = new JLabel(backIcon);
      back.setBounds(55,65,840,500);    
      
      titleLabel = new JLabel("JOIN THE DOTS");
      titleLabel.setFont(new Font("Arial Black", Font.PLAIN, 36));
      titleLabel.setBounds(350,20,600,50);
      
      returnIcon = new ImageIcon("return1.png");
      retrn = new JButton(returnIcon);
      retrn.setBounds(910,490,50,50);
      retrn.setBackground(Color.BLUE);
      retrn.addActionListener(new CreditsListener());
      
      
   }
   // adding components
   public void addComponents(){
      
      
      setLayout(null);
      add(titleLabel);
      add(retrn);
      add(back);
      repaint();
      
   }
   
   
   /**
    * This method draws image to panel
    *@param g is the graphics 
    */
   
   public void paintComponent(Graphics g) {
      
      g.drawImage(img.getImage(), 0, 0, null);
      
   }
   
   
   
   //CreditsListener class
   private class CreditsListener implements ActionListener{
      
      public void actionPerformed(ActionEvent e){
         
         
         
         if(e.getSource()==retrn){
            
            try {
               
               Intro panel = new Intro();
               panel.setBounds(0,0,1000,600);
               removeAll();
               
               add(panel);
               repaint();
               
            }
            catch( IOException except ) {
               
               System.out.println("could not write to the file");
            }     
         }
      }
   }
}