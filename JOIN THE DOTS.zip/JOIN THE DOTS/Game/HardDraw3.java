import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.io.*;

public class HardDraw3 extends JPanel {
   //Varieables
   int score;
   boolean isOver;
   boolean lose = false;
   HelpfulMethods info;
   int correctCounter = 0;
   int id;
   boolean memoryTimeOver = false;
   ArrayList<JButton> buttons;
   ArrayList<Integer> allX;
   ArrayList<Integer> allY;
   ArrayList<Integer> randX;
   ArrayList<Integer> randY;
   
   //Constructor
   public HardDraw3(String gameMode,HelpfulMethods info , int id) {
      
      setLayout(null);
      buttons = new ArrayList<JButton>();
      allX = new ArrayList<Integer>();
      allY = new ArrayList<Integer>();
      randX = new ArrayList<Integer>();
      randY = new ArrayList<Integer>();
      setBackground( new Color(51, 204, 255) );
      
      for(int i = 1 ; i <= 15 ; i++ ) {
         
         allX.add(i);
         if( i <= 12 ) {
            allY.add(i);
         }
      }
      
      for(int i = 0 ; i < 9 ; i++ ) {
         
         int randomX = (int) (Math.random() * allX.size()) ;
         int randomY = (int) (Math.random() * allY.size());
         int x = allX.get(randomX);
         int y = allY.get(randomY);
         randX.add(x);
         randY.add(y);
         allX.remove(randomX);
         allY.remove(randomY);
         
      }
      for( int i = 0 ; i < 9 ; i++ ) {
         JButton a = new JButton(""+(i+1));
         a.setBounds((randX.get(i) - 1)*50 , (randY.get(i) - 1 ) * 50 , 50 ,50);
         a.addActionListener(new GameListener());
         buttons.add(a);
         add(a);
      }
      
   }
   
   /**
    * This method gives boolean depending on lose condition 
    *@return returns true or false depending on the situation
    */
   public boolean getLose() {
      return lose;
   }
   /**
    * This method gives boolean depending on lose condition 
    *@return returns true or false depending on the situation
    */
   public boolean getMemoryTimeOver() {
      return memoryTimeOver;
   }
   /**
    * This method gives boolean depending on lose condition 
    * @param time is the boolean that is given
    */
   public void setMemoryTimeOver(boolean time) {
      memoryTimeOver = time;
   }
   /**
    * This method gives back if game is over
    *@return retruns true or false depending on the situation
    */
   public boolean getIsOver(){
      
      return isOver;
      
   }
   /**
    * This method sets isover boolean
    *@param temp is boolean that we want to isOver be
    */
   public void setIsOver(boolean temp){
      
      isOver = temp;
      
   }
   /**
    * This method gives back the score
    *@return retruns score
    */
   public int getScore() {
      return score;
   }
   /**
    * This method draws buttons to panel
    */
   public void draw() {
      for(int i = 0 ; i < buttons.size() ; i++ ) {
         
         buttons.get(i).setText("");
         
      }
   }
   //GameListener class
   private class GameListener implements ActionListener {
      public void actionPerformed(ActionEvent e){
         int number;
         Object obj = e.getSource();
         JButton b = (JButton) obj;
         int x = b.getX();
         int y = b.getY();
         if(memoryTimeOver) {
            if( x == (randX.get(correctCounter) - 1)*50 && y == (randY.get(correctCounter) - 1)*50) {
               score = score + 5;
               correctCounter++;
               b.setEnabled(false);
               
            }
            else {
               isOver = true;
               lose = true;
            }
         }
         
         if( correctCounter == 9 ) {
            
            isOver = true;
         }
      }
   } 
}





