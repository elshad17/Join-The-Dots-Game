import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class HighScores extends JPanel{
   //Variables
   Player player;
   int id;
   HelpfulMethods info;
   JButton retrn;
   JLabel nameLabel,rankLabel,player1IconLabel,player2IconLabel,player3IconLabel,titleLabel,cupLabel;
   JLabel player1NameLabel,player2NameLabel,player3NameLabel,player1RankLabel,player2RankLabel,player3RankLabel;
   ImageIcon player1Icon,player2Icon,player3Icon,returnIcon,cupIcon;
   ImageIcon img = new ImageIcon("back.jpg");
   ArrayList<Integer> topScores ;
   ArrayList<String> topIcons;
   ArrayList<String> topNames;
   
   //Constructor
   public HighScores(HelpfulMethods info, int id){
      this.info = info;
      this.id = id;
      createComponents();
      addComponents();
      
   }
   //Create components
   public void createComponents(){
      
      topNames = info.findtopNames(info.getallPlayers());
      topScores = info.findtopScores();
      topIcons = info.findtopIcons();
      cupIcon = new ImageIcon("cup.png");
      //Header
      nameLabel = new JLabel("NAMES");
      nameLabel.setFont(new Font("Arial Black", Font.PLAIN, 20));
      nameLabel.setBounds(400,150,100,50);
      //Header
      rankLabel = new JLabel("HIGHEST SCORES");
      rankLabel.setFont(new Font("Arial Black", Font.PLAIN, 20));
      rankLabel.setBounds(600,150,200,50);
      //Icons
      player1Icon = new ImageIcon(topIcons.get(0));
      player2Icon = new ImageIcon(topIcons.get(1)); 
      player3Icon = new ImageIcon(topIcons.get(2));
      returnIcon = new ImageIcon("return1.png");
      
      //Icon Labels
      player1IconLabel = new JLabel(player1Icon);
      player1IconLabel.setBounds(250,200,50,50);
      
      player2IconLabel = new JLabel(player2Icon);
      player2IconLabel.setBounds(250,260,50,50);
      
      player3IconLabel = new JLabel(player3Icon); 
      player3IconLabel.setBounds(250,320,50,50);
      
      //Name Labels
      player1NameLabel = new JLabel(topNames.get(0));
      player1NameLabel.setFont(new Font("Arial Black", Font.PLAIN, 15));
      player1NameLabel.setBounds(400,200,100,50);
      
      player2NameLabel = new JLabel(topNames.get(1));
      player2NameLabel.setFont(new Font("Arial Black", Font.PLAIN, 15));
      player2NameLabel.setBounds(400,260,100,50);
      
      player3NameLabel = new JLabel(topNames.get(2));
      player3NameLabel.setFont(new Font("Arial Black", Font.PLAIN, 15));
      player3NameLabel.setBounds(400,320,100,50);
      
      //Rank Labels
      player1RankLabel = new JLabel(""+topScores.get(0));
      player1RankLabel.setFont(new Font("Arial Black", Font.PLAIN, 15));
      player1RankLabel.setBounds(700,200,100,50);
      
      player2RankLabel = new JLabel(""+topScores.get(1));
      player2RankLabel.setFont(new Font("Arial Black", Font.PLAIN, 15));
      player2RankLabel.setBounds(700,260,100,50);
      
      player3RankLabel = new JLabel(""+topScores.get(2));
      player3RankLabel.setFont(new Font("Arial Black", Font.PLAIN, 15));
      player3RankLabel.setBounds(700,320,100,50);
      
      //Return button
      retrn = new JButton(returnIcon );
      retrn.setBounds(900,500,50,40);
      retrn.addActionListener(new HighScoreListener());
      
      //Title Label
      titleLabel = new JLabel("HIGH SCORES");
      titleLabel.setFont(new Font("Arial Black", Font.PLAIN, 36));
      titleLabel.setBounds(380,20,600,50);
      
      cupLabel = new JLabel(cupIcon);
      cupLabel.setBounds(190,200,50,50);      
   }
   
   // adding components
   public void addComponents(){
      
      
      setLayout(null);
      
      add(retrn);
      add(titleLabel);
      add(player1IconLabel);
      add(player2IconLabel);
      add(player3IconLabel);
      add(nameLabel);
      add(rankLabel);
      add(player1NameLabel);
      add(player2NameLabel);
      add(player3NameLabel);
      add(player1RankLabel);
      add(player2RankLabel);
      add(player3RankLabel);
      add(cupLabel);
      repaint();  
   }
   /**
    * This method draws image to panel
    *@param g is the graphics 
    */
   public void paintComponent(Graphics g) {
      
      g.drawImage(img.getImage(), 0, 0, null);
   }
   
   //Action Listener
   private class HighScoreListener implements ActionListener{
      
      public void actionPerformed(ActionEvent e){
         
         if(e.getSource()==retrn){
            
            
            MenuPanel panel = new MenuPanel(info,id);
            panel.setBounds(0,0,1000,600);
            removeAll();
            add(panel);
            repaint();
            
            
            
         }
      }  
   }      
}