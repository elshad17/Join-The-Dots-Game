import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.io.*;

public class MediumDraw1 extends JPanel {
   //Variable
   HelpfulMethods info;
   int score = 0;
   int id;
   String gameMode;
   ArrayList<Integer> x = new ArrayList<Integer>();
   ArrayList<Integer> y = new ArrayList<Integer>();
   ArrayList<Integer> textFieldX = new ArrayList<Integer>();
   ArrayList<Integer> textFieldY = new ArrayList<Integer>();
   ArrayList<Integer> textFieldWidth = new ArrayList<Integer>();
   ArrayList<Integer> textFieldSize = new ArrayList<Integer>();
   ArrayList<JButton> buttons = new ArrayList<JButton>();
   ArrayList<JTextField> textFields = new ArrayList<JTextField>();
   ArrayList<JButton> clickedButtons = new ArrayList<JButton>();
   ArrayList<JTextField> writtenTextFields = new ArrayList<JTextField>();
   int counter =0;
   boolean condition = false;
   boolean checker = false;
   boolean isOver = false;
   ImageIcon img = new ImageIcon("owl.png");
   
   //Constructor
   public MediumDraw1(String gameMode,HelpfulMethods info , int id){
      this.info = info;
      this.id = id;
      setLayout(null);
      this.gameMode = gameMode;
      
   }
   /**
     * This method gives back if game is over
    *@return retruns true or false depending on the situation
    */
   
   public boolean getIsOver(){
      
      return isOver;
      
   }
   
   /**
    * This method sets is over boolean
    *@param temp is boolean that we want to isOver be
    */
   public void setIsOver(boolean temp){
      
      isOver = temp;
      
   }
   
   /**
    * This method draws image to panel
    *@param g is the graphics 
    */
   
   public void paintComponent(Graphics g) {
      
      Graphics2D g2 = (Graphics2D) g;
      g.drawImage(img.getImage(), 0, 0, null);
      if (checker){
         for(int i = 0 ; i < counter; i++ ) {
            g2.setStroke(new BasicStroke(4));
            g2.drawLine(x.get(i),y.get(i),x.get(i+1),y.get(i+1));
            
         }
         checker = false;
         condition = false;
      }
   }
   
   /**
    * This method checks if given input is integer
    * @param input is input that wants to be checken
    *@return returns true or false depending on the situation
    */
   
   public boolean isInteger( String input ) {
      
      try
      {
         Integer.parseInt( input );
         return true;
      }
      catch( Exception e)
      {
         return false;
      }
   }
   
   // This method draws a game
   public void draw() {
      
      try {
         
         
         if(gameMode.equals("GAME 1")){
            
            MediumGameDotsCollection MGame1collection = new MediumGameDotsCollection();
            
            x =  MGame1collection.getMediumX1Coordinate();
            y =  MGame1collection.getMediumY1Coordinate();
            textFieldX = MGame1collection.getTextFieldX1();
            textFieldY = MGame1collection.getTextFieldY1();
            textFieldWidth = MGame1collection.getTextFieldWidth1();
            textFieldSize = MGame1collection.getTextFieldSize1();
            
//            for(int i = 0 ; i < x.size() ; i++ )  {
//               System.out.println(x.get(i));
//               System.out.println(y.get(i));
//            }
            for(int i =0;i<x.size();i++){
               
               JButton a = new JButton(""+(i+1));
               a.addActionListener(new GameListener());
               a.setBounds(x.get(i),y.get(i),10,10);
               buttons.add(a);
               add(a);
               
               int width = 4;
               JTextField b = new JTextField(width);
               b.addKeyListener(new EnterListener());
               b.setText("");
               b.setBounds(textFieldX.get(i),textFieldY.get(i),textFieldWidth.get(i),textFieldSize.get(i));
               textFields.add(b);
               add(b);
               
               
            }
            clickedButtons.add(buttons.get(0));
            
            int random = (int) (Math.random() * 6);
            textFields.get(0).setText("+"+random);
            writtenTextFields.add(textFields.get(0));
            textFields.get(0).setEditable(false);
            
            
            
         }
      }
      catch( IOException except ) {
         
         System.out.println("could not write to the file");
      } 
   }
   /**
    * This method gives back the score
    *@return retruns score
    */
   public int getScore() {
      return score;
   }
   
   //GameListener class
   private class GameListener implements ActionListener{
      
      
      public void actionPerformed(ActionEvent e){
         int number;
         int textNumber;
         int previousButton;
         int textNumberBefore;
         int textNumberCurrent = 0;
         String strtextNumberBefore;
         String strtextNumberCurrent;
         condition = false;
         
         
         Object obj = e.getSource();
         JButton a = (JButton) obj;
         number = Integer.parseInt(a.getText());
         
         strtextNumberBefore = writtenTextFields.get(counter).getText().substring(1);
         strtextNumberCurrent = textFields.get(counter+1).getText();
         textNumberBefore = Integer.parseInt(strtextNumberBefore);
         if(isInteger(strtextNumberCurrent)) {
            Character c = strtextNumberCurrent.charAt(0);
            if( !Character.isDigit(c) ) {
               textNumberCurrent = 0;
            }
            else {
               textNumberCurrent = Integer.parseInt(strtextNumberCurrent);
            }
         }
         previousButton = Integer.parseInt(clickedButtons.get(counter).getText());
         
         if( number - 1 == Integer.parseInt(clickedButtons.get(counter).getText()) ) {
            if(textNumberBefore + previousButton == textNumberCurrent) {
               score = score + 5;
               counter++;
               clickedButtons.add(a);
               writtenTextFields.add(textFields.get(counter)); // counter just got increased by one.
               condition = true;
               
               
            }   
         }
         
         if( counter != 0 && condition ) {
            if(Integer.parseInt(clickedButtons.get(clickedButtons.size()-2).getText())== Integer.parseInt(clickedButtons.get(clickedButtons.size()-1).getText())-1){
               
               checker = true;
               repaint();
               int random = (int) (Math.random() * 6);
               writtenTextFields.get(counter).setText("+"+random);
               writtenTextFields.get(counter).setEditable(false);
            }
         }
         
         if( clickedButtons.size() == buttons.size() ) {
            
            isOver = true;
            
            
         }
      }
   }
   //EnterListener class
   private class EnterListener implements KeyListener{
      
      public void keyPressed(KeyEvent evt){
         if(evt.getKeyCode() == KeyEvent.VK_ENTER) {
            
         }
         
      }
      public void keyTyped(KeyEvent evt){
         
      }
      
      public void keyReleased(KeyEvent evt) {
         
      }  
   } 
}