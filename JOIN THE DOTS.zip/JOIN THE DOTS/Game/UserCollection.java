import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;

public class UserCollection {
   
   // instance variables 
   ArrayList<String> users; // strings obtained from reading users.txt
   ArrayList<String> iconPaths; // strings obtained from reading icons.txt
   ArrayList<Player> players; // player arraylist which created by using users
   UserFile userList;
   Player player;
   public UserCollection() throws FileNotFoundException {
      
      players = new ArrayList<Player>();
      userList = new UserFile();
      userList.userfileToList();
      userList.iconfileToList();
      users = userList.getList();
      iconPaths = userList.geticonList();
      Player player;
      Scanner in;
      String strID;
      int id;
      String name;
      String strScore;
      int score;
      String path;
      String rank;
      int easygame1;
      int easygame2;
      int easygame3;
      int mediumgame1;
      int mediumgame2;
      int mediumgame3;
      int hardgame1;
      int hardgame2;
      int hardgame3;
      
      // creating player arraylist
      for( int i = 0 ; i < users.size() ; i++ ) {
         
         in = new Scanner(users.get(i));
         in.useDelimiter("/");
         strID = in.next();
         id = Integer.parseInt(strID);
         name = in.next();
         strScore = in.next();
         score = Integer.parseInt(strScore);
         path = in.next();
         rank = in.next();
         easygame1 = Integer.parseInt( in.next() );
         easygame2 = Integer.parseInt( in.next() );
         easygame3 = Integer.parseInt( in.next() );
         mediumgame1 = Integer.parseInt( in.next() );
         mediumgame2 = Integer.parseInt( in.next() );
         mediumgame3 = Integer.parseInt( in.next() );
         hardgame1 = Integer.parseInt( in.next() );
         hardgame2 = Integer.parseInt( in.next() );
         hardgame3 = Integer.parseInt( in.next() );
         player = new Player(name);
         player.setRank(rank);
         player.setHighestRank(rank);
         player.setHighestScore(score);
         player.setplayerID(id);
         player.seticonPath(path);
         player.seteasyGame1(easygame1);
         player.seteasyGame2(easygame2);
         player.seteasyGame3(easygame3);
         player.setmediumGame1(mediumgame1);
         player.setmediumGame2(mediumgame2);
         player.setmediumGame3(mediumgame3);
         player.sethardGame1(hardgame1);
         player.sethardGame2(hardgame2);
         player.sethardGame3(hardgame3);
         
         players.add(player);
         
      }
   } 
   /** This method gets players.
     *@return returns players.
     */
   public ArrayList<Player> getplayerList() {
      return players;
   }
   /** This method gets icon List of the players.
     *@return returns icons.
     */
   public ArrayList<String> geticonList() {
      return iconPaths;
      
   }
}
