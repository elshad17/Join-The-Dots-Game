import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class GameOver extends JPanel{
   //Variables
   HelpfulMethods info;
   int id;
   Player player;
   String mode;
   JLabel titleLabel;
   JButton ok;
   ImageIcon img = new ImageIcon("back.jpg");
   
    //Constructor
   public GameOver(String mode,HelpfulMethods info, int id){
      this.info = info;
      this.id = id;
      this.mode = mode;
      createComponents();
      addComponents();
     
      
   }
   //Create components
   public void createComponents(){
      
      ok = new JButton("OK");
      ok.setBounds(420,210,170,40);
      ok.setFont(new Font("Arial Black", Font.PLAIN, 18));
      ok.addActionListener(new GameListener());
      ok.setBackground(Color.RED);
      
      titleLabel = new JLabel("GAME OVER");
      titleLabel.setFont(new Font("Arial Black", Font.PLAIN, 36));
      titleLabel.setBounds(380,120,600,50);
      
      
   }
   //Add components
   public void addComponents(){
      
      
      setLayout(null);
      
      add(ok);
      add(titleLabel);
      repaint();
      
      
      
   }
   //GameListener class
   private class GameListener implements ActionListener{
      
      public void actionPerformed(ActionEvent e){
         
         if(e.getSource()==ok && !mode.equals("CREATE GAME")){
            
            
            GameModes panel = new GameModes(mode,info,id);
            panel.setBounds(0,0,1000,600);
            removeAll();
            
            add(panel);
            repaint();
            
         }
         else if(e.getSource()==ok && mode.equals("CREATE GAME")){
            
            
            DifficultyLevel panel = new DifficultyLevel(info,id);
            panel.setBounds(0,0,1000,600);
            removeAll();
            
            add(panel);
            repaint();
            
         }
      }
   }
   
    /**
    * This method draws image to panel
    *@param g is the graphics 
    */
   public void paintComponent(Graphics g) {
      
      g.drawImage(img.getImage(), 0, 0, null);
      
   }
   
}