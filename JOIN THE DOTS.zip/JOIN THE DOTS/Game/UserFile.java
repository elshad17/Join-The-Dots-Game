import java.util.ArrayList;
import java.io.*;
import java.util.Scanner;
public class UserFile {
   
   //instance variables
   private ArrayList<String> list; // the list whcih contains information of players.
   private ArrayList<String> iconList; // the list which contains information of paths of icons.
   
   // constructor
   public UserFile() {
      
      list = new ArrayList<String>();
      iconList = new ArrayList<String>();
   }
   
   /**
    * This method reads the users.txt and stores into an arraylist.
    *  @exception FileNotFoundException if aFile does not exist.
    */
   public void userfileToList() throws FileNotFoundException {
      
      File file = new File("users.txt");
      Scanner in = new Scanner(file);
      String line;
      
      while( in.hasNextLine() ) {
         
         line = in.nextLine();
         list.add(line);
      }
      in.close();
   }
   /**
    * This method takes a player arraylist and writes neccessary information to users.txt
    *  @exception FileNotFoundException if aFile does not exist.
    *@param players is an arraylist which contains players.
    */
   public void listToFile(ArrayList<Player> players) throws FileNotFoundException  {
      
      PrintWriter writer = new PrintWriter("users.txt");
      String str;
      
      for(int i = 0 ; i < players.size() ; i++ ) {
         
         str = players.get(i).toString();
         writer.println(str);
      }
      writer.close();
   }
   
   
   /** This method sets icons to the list
     *  @exception FileNotFoundException if aFile does not exist.
     */
   public void iconfileToList() throws FileNotFoundException {
      
      File file = new File("icons.txt"); 
      Scanner in = new Scanner(file);
      String line;
      
      while( in.hasNextLine() ) {
         
         line = in.nextLine();
         iconList.add(line);
      }
      in.close();
   }      
   
   /** This method returns the string arraylist which contains information of players.
     *@return list is the list which contains information of players.
     */
   
   public ArrayList<String> getList() {
      return list;
   }
   /**
    * This method returns the string arraylist which contains information of players icon path.
    *@return iconList is the list which contains information of players icon path.
    */
   public ArrayList<String> geticonList() {
      return iconList;
   }
}








