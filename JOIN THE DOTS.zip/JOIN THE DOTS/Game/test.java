import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class test{
   
   public static void main (String[] args) throws FileNotFoundException {
      
      //testing program
      JFrame frame  = new JFrame();
      Intro panel = new Intro();
      frame.add(panel);     
      frame.setSize(1000,645);
      frame.setVisible(true);
      
   }
   
   
}