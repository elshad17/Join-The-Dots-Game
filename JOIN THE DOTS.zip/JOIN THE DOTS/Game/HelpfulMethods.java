import java.util.ArrayList;
import java.util.Scanner;
public class HelpfulMethods {
   
   private ArrayList<Player> players;
   private ArrayList<String> iconPaths;
   public HelpfulMethods(ArrayList<Player> players, ArrayList<String> iconPaths) {
      this.iconPaths = iconPaths;
      this.players = players;
   }
   
   /**
    * This method gets a name as a parameter, checks the players if this name is already taken. If it is, it reloads neccesary informations
    * for this player and sets it. If not, just creates a new player, adds it to the player arraylist and returns it.
    * @param nickname is the name of the player
    *@return player is the player which just logged in.
    */
   public Player loginPlayer( String nickname )  {
      
      Player player;
      String name = "";
      int id;
      int score;
      String path;
      String rank;
      String highestRank;
      int easygame1;
      int easygame2;
      int easygame3;
      int mediumgame1;
      int mediumgame2;
      int mediumgame3;
      int hardgame1;
      int hardgame2;
      int hardgame3;
      
      // checks all players if the nickname taken as a parameter matches.
      for(int i = 0 ; i < players.size(); i++ ) {
         
         name = players.get(i).getName();
         
         // if the names match, it sets the player and returns.
         if( name.equals(nickname) ) {
            
            player = players.get(i);          
            return player;
         }         
      }
      // sets the id-name-score-rank-easygame1-easygame2-easygame3-mediumgame1-mediumgame2-mediumgame3-hardgame1-hardgame2-hardgame3
      id = players.size() + 1;
      name = nickname;
      score = 0;
      path = iconPaths.get(id - 1);
      rank = "F";
      highestRank = "F";
      easygame1 = 1;
      easygame2 = 0;
      easygame3 = 0;
      mediumgame1 = 1;
      mediumgame2 = 0;
      mediumgame3 = 0;
      hardgame1 = 1;
      hardgame2 = 0;
      hardgame3 = 0;
      player = new Player(name);
      player.setHighestScore(score);
      player.setplayerID(id);
      player.seticonPath(path);
      player.setRank(rank);
      player.setHighestRank(highestRank);
      player.seteasyGame1(easygame1);
      player.seteasyGame2(easygame2);
      player.seteasyGame3(easygame3);
      player.setmediumGame1(mediumgame1);
      player.setmediumGame2(mediumgame2);
      player.setmediumGame3(mediumgame3);
      player.sethardGame1(hardgame1);
      player.sethardGame2(hardgame2);
      player.sethardGame3(hardgame3);
      players.add(player);
      return player;
   }   
   
   /**
    * This method returns the string arraylist which contains the top 3 highest scores players names.
    * @param players that is given
    *@return names is the string arraylist of the top 3 highest scores players.
    */
   public ArrayList<String> findtopNames(ArrayList<Player> players) {
      
      ArrayList<Integer> id = findtopIDs();
      ArrayList<String> names = new ArrayList<String>();
      String name;
      
      
      for( int i = 0 ; i < id.size() ; i++ ) {
         
         name = players.get(id.get(i) - 1).getName();
         names.add(name);
      }
      return names;
   }
   
   /**
    * This method returns the string arraylist which contains the top 3 highest scores players icons.
    *@return iconPaths is the string arraylist of the top 3 highest scores players.
    */
   public ArrayList<String> findtopIcons() {
      
      ArrayList<Integer> id = findtopIDs();
      ArrayList<String> iconPaths = new ArrayList<String>();
      String path;
      
      for( int i = 0 ; i < id.size() ; i++ ) {
         
         path = players.get(id.get(i) - 1).geticonPath();
         iconPaths.add(path);
      }
      return iconPaths;
   }
   
   
   /**
    * This method uses returns the string arraylist which contains the top 3 highest scores players scores.
    *@return scores is the integer arraylist of the top 3 highest scores players.
    */
   public ArrayList<Integer> findtopScores()  {
      
      ArrayList<Integer> id = findtopIDs();
      ArrayList<Integer> scores = new ArrayList<Integer>();
      Scanner in;
      String strScore;
      int score;
      String line;
      
      for( int i = 0 ; i < id.size() ; i++ ) {
         
         score = players.get(id.get(i) - 1).getHighestScore();
         scores.add(score);
      }
      return scores;
   }
   
   /**
    * This method returns the integer arraylist which contains the top 3 highest scores players IDs.
    *@return topIDs is the integer arraylist of the top 3 highest scores players.
    */
   public ArrayList<Integer> findtopIDs() {
      
      ArrayList<Integer> topIDs = new ArrayList<Integer>();
      int indexMax = 0;
      int maxScore;
      int id;
      int currentScore;
      ArrayList<Player> copyPlayers = new ArrayList<Player>();
      
      for( int i = 0 ; i < players.size() ; i++ ) {
         
         copyPlayers.add(players.get(i));
      }
      
      id = players.get(0).getplayerID();
      maxScore = players.get(0).getHighestScore();
      
      for( int i = 0 ; i < 3 ; i++ ) {
         maxScore = copyPlayers.get(0).getHighestScore();
         id = copyPlayers.get(0).getplayerID();
         for( int j = 1 ; j < copyPlayers.size() ; j++ ) {
            
            currentScore = copyPlayers.get(j).getHighestScore();
            
            if( currentScore > maxScore ) {
               
               maxScore = currentScore;
               indexMax = j;
               id = copyPlayers.get(j).getplayerID();
            }
         }
         topIDs.add(id);
         copyPlayers.remove(indexMax);
         indexMax = 0;
      }
      
      return topIDs;
   }
   /**
    * This method gives back the listof Player
    *@return returns players list.
    */
   public ArrayList<Player> getallPlayers() {
      return players;
   }
}
