import java.util.ArrayList;
import java.io.*;
import java.util.Scanner;

public class MediumGameDotsCollection {
   
   // instance variables
   private ArrayList<String> dotsInfo1;
   private ArrayList<Integer> MGame1xCoordinates;
   private ArrayList<Integer> MGame1yCoordinates;
   private ArrayList<Integer> MGame1dotID;
   private ArrayList<Integer> MGame1textFieldX;
   private ArrayList<Integer> MGame1textFieldY;
   private ArrayList<Integer> MGame1textFieldWidth;
   private ArrayList<Integer> MGame1textFieldSize;
   private MediumGameDots MGame1dots;
   
   
   private ArrayList<String> dotsInfo2;
   private ArrayList<Integer> MGame2xCoordinates;
   private ArrayList<Integer> MGame2yCoordinates;
   private ArrayList<Integer> MGame2dotID;
   private ArrayList<Integer> MGame2textFieldX;
   private ArrayList<Integer> MGame2textFieldY;
   private ArrayList<Integer> MGame2textFieldWidth;
   private ArrayList<Integer> MGame2textFieldSize;
   private MediumGameDots MGame2dots;
   
   
   
   private ArrayList<String> dotsInfo3;
   private ArrayList<Integer> MGame3xCoordinates;
   private ArrayList<Integer> MGame3yCoordinates;
   private ArrayList<Integer> MGame3dotID;
   private ArrayList<Integer> MGame3textFieldX;
   private ArrayList<Integer> MGame3textFieldY;
   private ArrayList<Integer> MGame3textFieldWidth;
   private ArrayList<Integer> MGame3textFieldSize;
   private MediumGameDots MGame3dots;
   
   // constructor
   public MediumGameDotsCollection() throws FileNotFoundException {
      
      MGame1xCoordinates = new ArrayList<Integer>();
      MGame1yCoordinates = new ArrayList<Integer>();
      MGame1textFieldX = new ArrayList<Integer>();
      MGame1textFieldY = new ArrayList<Integer>();
      MGame1textFieldWidth = new ArrayList<Integer>();
      MGame1textFieldSize = new ArrayList<Integer>();
      MGame1dotID = new ArrayList<Integer>();
      MGame1dots = new MediumGameDots();
      MGame1dots.userfileToList();
      dotsInfo1 = MGame1dots.getMediumgame1Info();
      
      Scanner in1;
      String line1;
      String strDot1;
      String strX1;
      String strY1;
      String strtextFieldX1;
      String strtextFieldY1;
      String strtextFieldWidth1;
      String strtextFieldSize1;
      int dot1;
      int x1;
      int y1;
      int textFieldX1;
      int textFieldY1;
      int textFieldWidth1;
      int textFieldSize1;
      
      for( int i = 0 ; i < dotsInfo1.size() ; i++ ) {
         
         line1 = dotsInfo1.get(i);
         in1 = new Scanner(line1);
         in1.useDelimiter("/");
         strDot1 = in1.next();
         strX1 = in1.next();
         strY1 = in1.next();
         strtextFieldX1 = in1.next();
         strtextFieldY1 = in1.next();
         strtextFieldWidth1 = in1.next();
         strtextFieldSize1 = in1.next();
         dot1 = Integer.parseInt(strDot1);
         x1 = Integer.parseInt(strX1);
         y1 = Integer.parseInt(strY1);
         textFieldX1 = Integer.parseInt(strtextFieldX1);
         textFieldY1 = Integer.parseInt(strtextFieldY1);
         textFieldWidth1 = Integer.parseInt(strtextFieldWidth1);
         textFieldSize1 = Integer.parseInt(strtextFieldSize1);
         MGame1dotID.add(dot1);
         MGame1xCoordinates.add(x1);
         MGame1yCoordinates.add(y1);
         MGame1textFieldX.add(textFieldX1);
         MGame1textFieldY.add(textFieldY1);
         MGame1textFieldWidth.add(textFieldWidth1);
         MGame1textFieldSize.add(textFieldSize1);
      }
      
      
      
      MGame2xCoordinates = new ArrayList<Integer>();
      MGame2yCoordinates = new ArrayList<Integer>();
      MGame2textFieldX = new ArrayList<Integer>();
      MGame2textFieldY = new ArrayList<Integer>();
      MGame2textFieldWidth = new ArrayList<Integer>();
      MGame2textFieldSize = new ArrayList<Integer>();
      MGame2dotID = new ArrayList<Integer>();
      MGame2dots = new MediumGameDots();
      MGame2dots.userfileToList();
      dotsInfo2 = MGame2dots.getMediumgame2Info();
      
      Scanner in2;
      String line2;
      String strDot2;
      String strX2;
      String strY2;
      String strtextFieldX2;
      String strtextFieldY2;
      String strtextFieldWidth2;
      String strtextFieldSize2;
      int dot2;
      int x2;
      int y2;
      int textFieldX2;
      int textFieldY2;
      int textFieldWidth2;
      int textFieldSize2;
      
      for( int i = 0 ; i < dotsInfo2.size() ; i++ ) {
         
         line2 = dotsInfo2.get(i);
         in2 = new Scanner(line2);
         in2.useDelimiter("/");
         strDot2 = in2.next();
         strX2 = in2.next();
         strY2 = in2.next();
         strtextFieldX2 = in2.next();
         strtextFieldY2 = in2.next();
         strtextFieldWidth2 = in2.next();
         strtextFieldSize2 = in2.next();
         dot2 = Integer.parseInt(strDot2);
         x2 = Integer.parseInt(strX2);
         y2 = Integer.parseInt(strY2);
         textFieldX2 = Integer.parseInt(strtextFieldX2);
         textFieldY2 = Integer.parseInt(strtextFieldY2);
         textFieldWidth2 = Integer.parseInt(strtextFieldWidth2);
         textFieldSize2 = Integer.parseInt(strtextFieldSize2);
         MGame2dotID.add(dot2);
         MGame2xCoordinates.add(x2);
         MGame2yCoordinates.add(y2);
         MGame2textFieldX.add(textFieldX2);
         MGame2textFieldY.add(textFieldY2);
         MGame2textFieldWidth.add(textFieldWidth2);
         MGame2textFieldSize.add(textFieldSize2);
         in2.close();
      }
      
      
      
      MGame3xCoordinates = new ArrayList<Integer>();
      MGame3yCoordinates = new ArrayList<Integer>();
      MGame3textFieldX = new ArrayList<Integer>();
      MGame3textFieldY = new ArrayList<Integer>();
      MGame3textFieldWidth = new ArrayList<Integer>();
      MGame3textFieldSize = new ArrayList<Integer>();
      MGame3dotID = new ArrayList<Integer>();
      MGame3dots = new MediumGameDots();
      MGame3dots.userfileToList();
      dotsInfo3 = MGame3dots.getMediumgame3Info();
      
      Scanner in3;
      String line3;
      String strDot3;
      String strX3;
      String strY3;
      String strtextFieldX3;
      String strtextFieldY3;
      String strtextFieldWidth3;
      String strtextFieldSize3;
      int dot3;
      int x3;
      int y3;
      int textFieldX3;
      int textFieldY3;
      int textFieldWidth3;
      int textFieldSize3;
      
      for( int i = 0 ; i < dotsInfo3.size() ; i++ ) {
         
         
         line3 = dotsInfo3.get(i);
         in3 = new Scanner(line3);
         in3.useDelimiter("/");
         strDot3 = in3.next();
         strX3 = in3.next();
         strY3 = in3.next();
         strtextFieldX3 = in3.next();
         strtextFieldY3 = in3.next();
         strtextFieldWidth3 = in3.next();
         strtextFieldSize3 = in3.next();
         dot3 = Integer.parseInt(strDot3);
         x3 = Integer.parseInt(strX3);
         y3 = Integer.parseInt(strY3);
         textFieldX3 = Integer.parseInt(strtextFieldX3);
         textFieldY3 = Integer.parseInt(strtextFieldY3);
         textFieldWidth3 = Integer.parseInt(strtextFieldWidth3);
         textFieldSize3 = Integer.parseInt(strtextFieldSize3);
         MGame3dotID.add(dot3);
         MGame3xCoordinates.add(x3);
         MGame3yCoordinates.add(y3);
         MGame3textFieldX.add(textFieldX3);
         MGame3textFieldY.add(textFieldY3);
         MGame3textFieldWidth.add(textFieldWidth3);
         MGame3textFieldSize.add(textFieldSize3);
         in3.close();
      }
   }
   
   /**
    * This method takes two integers and sets a new dot.
    *@param x is the new dots x coordinate
    *@param y is the new dots y coordinate
    */
   public void addnextDot1(int x , int y) {
      
      MGame1xCoordinates.add(x);
      MGame1yCoordinates.add(y);
      MGame1dotID.add(MGame1xCoordinates.size() );
   }
   
   /**
    * This method takes two integers and sets a new dot.
    *@param x is the new dots x coordinate
    *@param y is the new dots y coordinate
    */
   
   public void addnextDot2(int x , int y) {
      
      MGame2xCoordinates.add(x);
      MGame2yCoordinates.add(y);
      MGame2dotID.add(MGame2xCoordinates.size() );
   }
   /**
    * This method takes two integers and sets a new dot.
    *@param x is the new dots x coordinate
    *@param y is the new dots y coordinate
    */
   
   public void addnextDot3(int x , int y) {
      
      MGame3xCoordinates.add(x);
      MGame3yCoordinates.add(y);
      MGame3dotID.add(MGame3xCoordinates.size() );
   }
   /**
    *  This method returns the arraylist which contains the IDs of dots.
    *@return EMgame1dotID is the arraylist which contains the IDs of dots.
    */
   public ArrayList<Integer> getMediumdotID1() {
      return MGame1dotID;
   }
   /**
    *  This method returns the arraylist which contains the x coordinates of dots.
    *@return EMgame1xCoordinates is the arraylist which contains x coordinates.
    */
   public ArrayList<Integer> getMediumX1Coordinate() {
      return MGame1xCoordinates;
   }
   /**
    * This method returns the arraylist which contains the y coordinates of dots.
    *@return EMgame1yCoordinates is the arraylist which contains y coordinates.
    */
   public ArrayList<Integer> getMediumY1Coordinate() {
      return MGame1yCoordinates;
   }
   
   /**
    * This method gives the text field.
    *@return returns MGame1textFieldX which is x coordinate.
    */
   
   public ArrayList<Integer> getTextFieldX1() {
      return MGame1textFieldX;
   }
   /**
    * This method gives the text field.
    *@return returns MGame1textFieldY which is y coordinate.
    */
   public ArrayList<Integer> getTextFieldY1() {
      return MGame1textFieldY;
   }
   /**
    * This method gives the text field width.
    *@return returns MGame1textFieldWidth .
    */
   public ArrayList<Integer> getTextFieldWidth1() {
      return MGame1textFieldWidth;
   }
   /**
    * This method gives the text field size.
    *@return returns MGame1textFieldSize .
    */
   
   public ArrayList<Integer> getTextFieldSize1() {
      return MGame1textFieldSize;
   }
   
   
   
   /**
    *  This method returns the arraylist which contains the IDs of dots.
    *@return EMgame1dotID is the arraylist which contains the IDs of dots.
    */
   public ArrayList<Integer> getMediumdotID2() {
      return MGame2dotID;
   }
   /**
    *  This method returns the arraylist which contains the x coordinates of dots.
    *@return EMgame1xCoordinates is the arraylist which contains x coordinates.
    */
   public ArrayList<Integer> getMediumX2Coordinate() {
      return MGame2xCoordinates;
   }
   /**
    * This method returns the arraylist which contains the y coordinates of dots.
    *@return EMgame1yCoordinates is the arraylist which contains y coordinates.
    */
   public ArrayList<Integer> getMediumY2Coordinate() {
      return MGame2yCoordinates;
   }
   /**
    * This method gives the text field.
    *@return returns MGame2textFieldX which is x coordinate.
    */
   public ArrayList<Integer> getTextFieldX2() {
      return MGame2textFieldX;
   }
   /**
    * This method gives the text field.
    *@return returns MGame2textFieldY which is y coordinate.
    */
   public ArrayList<Integer> getTextFieldY2() {
      return MGame2textFieldY;
   }
   /**
    * This method gives the text field width.
    *@return returns MGame2textFieldWidth .
    */
   public ArrayList<Integer> getTextFieldWidth2() {
      return MGame2textFieldWidth;
   }
   /**
    * This method gives the text field size.
    *@return returns MGame2textFieldSize .
    */
   public ArrayList<Integer> getTextFieldSize2() {
      return MGame2textFieldSize;
   }
   
   /**
    *  This method returns the arraylist which contains the IDs of dots.
    *@return EMgame1dotID is the arraylist which contains the IDs of dots.
    */
   public ArrayList<Integer> getMediumdotID3() {
      return MGame3dotID;
   }
   /**
    *  This method returns the arraylist which contains the x coordinates of dots.
    *@return EMgame1xCoordinates is the arraylist which contains x coordinates.
    */
   public ArrayList<Integer> getMediumX3Coordinate() {
      return MGame3xCoordinates;
   }
   /**
    * This method returns the arraylist which contains the y coordinates of dots.
    *@return EMgame1yCoordinates is the arraylist which contains y coordinates.
    */
   public ArrayList<Integer> getMediumY3Coordinate() {
      return MGame3yCoordinates;
   }
   
   /**
    * This method gives the text field.
    *@return returns MGame3textFieldX which is x coordinate.
    */
   public ArrayList<Integer> getTextFieldX3() {
      return MGame3textFieldX;
   }
   /**
    * This method gives the text field.
    *@return returns MGame3textFieldY which is y coordinate.
    */
   public ArrayList<Integer> getTextFieldY3() {
      return MGame3textFieldY;
   }
   /**
    * This method gives the text field width.
    *@return returns MGame3textFieldWidth .
    */
   public ArrayList<Integer> getTextFieldWidth3() {
      return MGame3textFieldWidth;
      
   }
   /**
    * This method gives the text field size.
    *@return returns MGame3textFieldWidth .
    */
   public ArrayList<Integer> getTextFieldSize3() {
      return MGame3textFieldSize;
   }
}







