import java.util.*;
// Player class
public class Player {
   
   // instance variables
   
   private int id; // players id
   private String name; // players nickname
   private String rank; // Ranks : A B C D E F  higher - lower. F fails. 
   private int highestScore; // players highest score
   private String highestRank;
   private int latestScore; // players latest score 
   private String iconPath; // the path of the icon
   private int easygame1;
   private int easygame2;
   private int easygame3;
   private int mediumgame1;
   private int mediumgame2;
   private int mediumgame3;
   private int hardgame1;
   private int hardgame2;
   private int hardgame3;
   
   // Constructor
   public Player( String name ) {
      
      this.name = name;
      rank = "F"; // lowest rank. 
      highestRank = "F";
   }
   
   // Mutator methods
   
   /**
    * This method takes a string as a parameter and sets it to players name.
    *@param name is the players name.
    */
   public void setName( String name ) {
      this.name = name;
   }
   /**
    * This method takes a string as a parameter and sets it to players rank.
    *@param rank is the players rank.
    */   
   public void setRank( String rank ) {
      this.rank = rank;
   }
   /**
    * This method takes a integer as a parameter and sets it to players highest score
    *@param highestScore is the players highest score.
    */
   public void setHighestScore( int highestScore ) {
      this.highestScore = highestScore;
   }
   /**
    * This method sets Highest rank
    *@param highestRank is the players highest rank.
    */
   public void setHighestRank( String highestRank ) {
      this.highestRank = highestRank;
   }
   /**
    * This method takes a integer as a parameter and sets it to players latest score.
    *@param latestScore is the players latest score.
    */
   public void setLatestScore( int latestScore ) {
      this.latestScore = latestScore;
   }
   /**
    * This method a integer parameter and sets it to players id.
    *@param id is the players id
    */
   public void setplayerID(int id) {
      this.id = id;
   }
   /**
    * This method takes a string parameter and sets it to players path for icon.
    *@param iconPath is the path of the players icon
    */
   public void seticonPath(String iconPath) {
      this.iconPath = iconPath;
   }
   /**
    * This method takes a integer value and sets it for easygame1 variable. If the parameter is 1. user will be able to play the easygame1.
    *@param easygame1 is the integer which shows if the user is able to play easygame1 or not.
    */
   public void seteasyGame1(int easygame1) {
      this.easygame1 = easygame1;
   }
   /**
    * This method takes a integer value and sets it for easygame2 variable. If the parameter is 1. user will be able to play the easygame2.
    *@param easygame2 is the integer which shows if the user is able to play easygame1 or not.
    */
   public void seteasyGame2(int easygame2) {
      this.easygame2 = easygame2;
   }
   /**
    * This method takes a integer value and sets it for easygame3 variable. If the parameter is 1. user will be able to play the easygame3.
    *@param easygame3 is the integer which shows if the user is able to play easygame1 or not.
    */
   public void seteasyGame3(int easygame3) {
      this.easygame3 = easygame3;
   }
   /**
    * This method takes a integer value and sets it for mediumgame1 variable. If the parameter is 1. user will be able to play the mediumgame1.
    *@param mediumgame1 is the integer which shows if the user is able to play easygame1 or not.
    */
   public void setmediumGame1(int mediumgame1) {
      this.mediumgame1 = mediumgame1;
   }
   /**
    * This method takes a integer value and sets it for mediumgame2 variable. If the parameter is 1. user will be able to play the mediumgame2.
    *@param mediumgame2 is the integer which shows if the user is able to play easygame1 or not.
    */
   public void setmediumGame2(int mediumgame2) {
      this.mediumgame2 = mediumgame2;
   }
   /**
    * This method takes a integer value and sets it for mediumgame3 variable. If the parameter is 1. user will be able to play the mediumgame3.
    *@param mediumgame3 is the integer which shows if the user is able to play easygame1 or not.
    */
   public void setmediumGame3(int mediumgame3) {
      this.mediumgame3 = mediumgame3;
   }
   /**
    * This method takes a integer value and sets it for hardgame1 variable. If the parameter is 1. user will be able to play the hardgame1.
    *@param hardgame1 is the integer which shows if the user is able to play easygame1 or not.
    */
   public void sethardGame1(int hardgame1) {
      this.hardgame1 = hardgame1;
   }
   /**
    * This method takes a integer value and sets it for hardgame2 variable. If the parameter is 1. user will be able to play the hardgame2.
    *@param hardgame2 is the integer which shows if the user is able to play easygame1 or not.
    */
   public void sethardGame2(int hardgame2) {
      this.hardgame2 = hardgame2;
   }
   /**
    * This method takes a integer value and sets it for hardgame3 variable. If the parameter is 1. user will be able to play the hardgame3.
    *@param hardgame3 is the integer which shows if the user is able to play easygame1 or not.
    */
   public void sethardGame3(int hardgame3) {
      this.hardgame3 = hardgame3;
   }
   
   // Accessor methods
   
   /**
    * This method gets the players name.
    *@return name is the players name
    */
   public String getName() {
      return name;
   }
   /**
    * This method gets the players rank
    *@return rank is the players rank
    */
   public String getRank() {
      return rank;
   }
   /**
    * This method gets the players highest score.
    *@return highestScore is the players highest score
    */
   public int getHighestScore() {
      return highestScore;
   }
   /**
    * This method gets the players highest rank.
    *@return retunrs the players highest rank
    */
   public String getHighestRank() {
      return highestRank;
   }
   /**
    * This method gets the players latest score.
    *@return latestScore is the players latest score.
    */
   public int getLatestScore() {
      return latestScore;
   }
   /**
    * This method gets the players id.
    *@return id is the players id.
    */
   public int getplayerID() {
      return id;
   }
   /**
    * This method gets the path of players icon.
    *@return iconPath is the path of the players icon.
    */
   public String geticonPath() {
      return iconPath;
   }
   /**
    * This method returns 1 or 0. That depends on if the user is able to play easygame1. If he/she is, this method returns 1.
    *@return easygame1 is the integer value of easygame1.
    */
   public int geteasyGame1() {
      return easygame1;
   }
   /**
    * This method returns 1 or 0. That depends on if the user is able to play easygame2. If he/she is, this method returns 1.
    *@return easygame2 is the integer value of easygame1.
    */
   public int geteasyGame2() {
      return easygame2;
   }
   /**
    * This method returns 1 or 0. That depends on if the user is able to play easygame3. If he/she is, this method returns 1.
    *@return easygame3 is the integer value of easygame1.
    */
   public int geteasyGame3() {
      return easygame3;
   }
   /**
    * This method returns 1 or 0. That depends on if the user is able to play mediumgame1. If he/she is, this method returns 1.
    *@return mediumgame1 is the integer value of easygame1.
    */
   public int getmediumGame1() {
      return mediumgame1;
   }
   /**
    * This method returns 1 or 0. That depends on if the user is able to play mediumgame2. If he/she is, this method returns 1.
    *@return mediumgame2 is return the integer value of easygame1.
    */
   public int getmediumGame2() {
      return mediumgame2;
   }
   /**
    * This method returns 1 or 0. That depends on if the user is able to play mediumgame3. If he/she is, this method returns 1.
    *@return mediumgame3 is the integer value of easygame1.
    */
   public int getmediumGame3() {
      return mediumgame3;
   }
   /**
    * This method returns 1 or 0. That depends on if the user is able to play hardgame1. If he/she is, this method returns 1.
    *@return hardgame1 is the integer value of easygame1.
    */
   public int gethardGame1() {
      return hardgame1;
   }
   /**
    * This method returns 1 or 0. That depends on if the user is able to play hardgame2. If he/she is, this method returns 1.
    *@return hardgame2 is the integer value of easygame1.
    */
   public int gethardGame2() {
      return hardgame2;
   }
   /**
    * This method returns 1 or 0. That depends on if the user is able to play hardgame3. If he/she is, this method returns 1.
    *@return hardgame3 is the integer value of easygame1.
    */
   public int gethardGame3() {
      return hardgame3;
   }
   
   // other methods
   
   /**
    * This method takes a score as a parameter. If that score is higher than the current highest score, sets a new highest score and a new rank. Then returns true.
    *@param score is the score.
    *@return true or false it depends on the score.
    */
   public boolean newHighestScore( int score ) {
      
      if( score > highestScore ) {
         
         highestScore = score; // new highest score 
         return true;
      }
      return false;
   }
   /**
    * This method takes a score as a parameter and check if it is new Highest Rank score
    *@param newScore is the new score.
    *@return true or false it depends on the condition.
    */
   public boolean newHighestRank( int newScore ) {
      String newRank;
      newRank = scoreToRank(newScore);
      
      if(newRank.compareTo(highestRank) < 0 ) {
         
         setHighestRank(newRank);
         setRank(highestRank);
         return true;
      }
      setRank(newRank);
      
      
      return false;
   }   
   
   /**
    * This method takes a score as a parameter and converts it to a rank and returns it.
    *@param score is the score which going to be converted to rank.
    *@return newRank
    */
   public String scoreToRank( int score ) {
      
      String temp;
      if( score >= 100 ) {
         temp  = "A";
      }
      else if( score >= 85 ) {
         temp = "B";
      }
      else if( score >= 60) {
         temp = "C";
      }
      else if( score >= 30 ) {
         temp = "D";
      }
      else if( score >= 0) {
         temp = "E";
      }
      else {
         temp = "F";
      }
      
      
      return temp;
   }
   /**
    * This method uses gets methods to get information of player and puts it in a string.
    *@return disp is the string format of the players. Check the users.txt if you want to see it.
    */
   public String toString() {
      
      String disp;
      disp = getplayerID() +"/" +getName() +"/" +getHighestScore() +"/" +geticonPath() +"/" +getRank() +"/"
         +geteasyGame1() +"/" +geteasyGame2() +"/" +geteasyGame3() +"/" + getmediumGame1() +"/"
         +getmediumGame2() +"/" +getmediumGame3() +"/" +gethardGame1() +"/" +gethardGame2() +"/" +gethardGame3();
      return disp;
   }
   
   
   
   
}