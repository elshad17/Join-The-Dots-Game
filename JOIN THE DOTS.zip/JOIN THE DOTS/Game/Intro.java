import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;

public class Intro extends JPanel {
   
   //Variables
   ArrayList<Player> players;
   ArrayList<String> iconPaths;
   UserCollection users;
   HelpfulMethods info;
   JButton enter, instructions, credits, quit;
   JLabel titleLabel;
   ImageIcon img = new ImageIcon("back.jpg");
   
   //Constructor
   public Intro() throws FileNotFoundException {
      
      users = new UserCollection();
      players = users.getplayerList();
      iconPaths = users.geticonList();
      info = new HelpfulMethods(players,iconPaths);
      
      createComponents();
      addComponents();
      
   }
   //Create components
   public void createComponents() {
      
      setLayout(null);
      
      enter = new JButton("START");
      ActionListener listener = new ButtonListener();
      enter.addActionListener(listener);
      enter.setFont(new Font("Arial Black", Font.PLAIN, 20));
      enter.setBounds(420,150,200,90);
      enter.setBackground(Color.GREEN);
      
      
      instructions = new JButton("INSTRUCTIONS");
      instructions.addActionListener(listener);
      instructions.setFont(new Font("Arial Black", Font.PLAIN, 18));
      instructions.setBounds(420,250,200,90);
      instructions.setBackground(Color.YELLOW);
      
      credits = new JButton("CREDITS");
      credits.addActionListener(listener);
      credits.setFont(new Font("Arial Black", Font.PLAIN, 20));
      credits.setBounds(420,350,200,90);
      credits.setBackground(Color.BLUE);
      
      titleLabel = new JLabel("JOIN the DOTS");
      titleLabel.setFont(new Font("Arial Black", Font.PLAIN, 40));
      titleLabel.setBounds(350,30,500,100);
      
      quit = new JButton("QUIT");
      quit.addActionListener(listener);
      quit.setFont(new Font("Arial Black", Font.PLAIN, 20));
      quit.setBounds(420,450,200,90);
      quit.setBackground(Color.RED);
      
      
   }
   // adding components
   public void addComponents() {
      
      add(enter);
      add(instructions);
      add(credits);
      add(titleLabel);
      add(quit);
   }
   
   /**
    * This method draws image to panel
    *@param g is the graphics 
    */
   public void paintComponent(Graphics g) {
      g.drawImage(img.getImage(), 0, 0, null);
   }
   
   //ButtonListener class
   private class ButtonListener implements ActionListener {
      
      public void actionPerformed(ActionEvent event) {
         
         Object obj = event.getSource();
         
         if( obj instanceof JButton ) {
            
            JButton castedButton = (JButton) obj;
            
            if( castedButton.getText().equals("START") ) {
               
               Username username = new Username(info);
               username.setBounds(0,0,1000,600);
               removeAll();
               
               add(username);
               repaint();
            }
            else  if( castedButton.getText().equals("CREDITS") ) {
               
               Credits panel = new Credits();
               panel.setBounds(0,0,1000,600);
               removeAll();
               
               add(panel);
               repaint();
            }
            else  if( castedButton.getText().equals("INSTRUCTIONS") ) {
               
               Instructions panel = new Instructions();
               panel.setBounds(0,0,1000,600);
               removeAll();
               
               add(panel);
               repaint();
            }
            
            else  if( castedButton.getText().equals("QUIT") ) {
               
               System.exit(0);
            }   
         }
      }
   }
}