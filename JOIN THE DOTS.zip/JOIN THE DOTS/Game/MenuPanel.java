import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class MenuPanel extends JPanel{
   
   //variables
   
   Player player;
   int id;
   HelpfulMethods info;
   JButton play,score,retrn,quit;
   JLabel playLabel,scoreLabel,retrnLabel,quitLabel,titleLabel,image;
   ImageIcon playIcon,scoreIcon,returnIcon,quitIcon,imageIcon;
   ImageIcon img = new ImageIcon("back.jpg");
   
   
   //Constructor
   public MenuPanel(HelpfulMethods info , int id){
      this.info = info;
      this.id = id;
      createComponents();
      addComponents();
      
   }
   //creating component
   public void createComponents(){
      
      
      playIcon = new ImageIcon("play.png");
      scoreIcon = new ImageIcon("diamond.png");
      returnIcon = new ImageIcon("return1.png");
      quitIcon = new ImageIcon("quit.png");
      imageIcon = new ImageIcon("back.jpg");
      
      play = new JButton("PLAY");
      play.setBounds(450,150,170,60);
      play.setBackground(Color.RED);
      play.setFont(new Font("Arial Black", Font.PLAIN, 24));
      play.addActionListener(new MyMenuListener());
      
      
      score = new JButton("High Scores");
      score.setBounds(450,230,170,60);
      score.setBackground(Color.CYAN);
      score.setFont(new Font("Arial Black", Font.PLAIN, 19));
      score.addActionListener(new MyMenuListener());
      
      retrn = new JButton("RETURN");
      retrn.setBounds(450,310,170,60);
      retrn.setBackground(Color.ORANGE);
      retrn.setFont(new Font("Arial Black", Font.PLAIN, 24));
      retrn.addActionListener(new MyMenuListener());
      
      quit = new JButton("QUIT");
      quit.setBounds(450,390,170,60);
      quit.setBackground(Color.BLUE);
      quit.setFont(new Font("Arial Black", Font.PLAIN, 24));
      quit.addActionListener(new MyMenuListener());
      
      playLabel = new JLabel(playIcon);
      playLabel.setBounds(350,150,80,60);
      
      scoreLabel = new JLabel(scoreIcon);
      scoreLabel.setBounds(350,230,80,60);
      
      
      retrnLabel = new JLabel(returnIcon);
      retrnLabel.setBounds(350,310,80,60);
      
      quitLabel = new JLabel(quitIcon);
      quitLabel.setBounds(350,390,80,60);
      
      titleLabel = new JLabel("MAIN MENU");
      titleLabel.setFont(new Font("Arial Black", Font.PLAIN, 36));
      titleLabel.setBounds(380,20,600,50);
      
      
   }
   
   //adding component
   public void addComponents(){
      
      
      setLayout(null);
      
      add(play);
      add(playLabel);
      add(score);
      add(retrn);
      add(quit);
      add(scoreLabel);
      add(retrnLabel);
      add(quitLabel);
      add(titleLabel);
      repaint();
      
      
      
   }
   /**
    * This method draws image to panel
    *@param g is the graphics 
    */
   
   public void paintComponent(Graphics g) {
      
      g.drawImage(img.getImage(), 0, 0, null);
      
   }
   
   //Menu Listener class
   private class MyMenuListener implements ActionListener{
      
      public void actionPerformed(ActionEvent e){
         
         if(e.getSource()==play){
            
            
            DifficultyLevel panel = new DifficultyLevel(info,id);
            panel.setBounds(0,0,1000,600);
            removeAll();
            
            add(panel);
            repaint();
            
         }
         
         else if(e.getSource()==retrn){
            Username panel = new Username(info);
            panel.setBounds(0,0,1000,600);
            removeAll();
            
            add(panel);
            repaint();
            
            
         }
         
         else if(e.getSource()==score){
            HighScores panel = new HighScores(info,id);
            panel.setBounds(0,0,1000,600);
            removeAll();
            
            add(panel);
            repaint();
            
            
         }
         else if(e.getSource()==quit){
            try {
               UserFile userfile = new UserFile();
               userfile.listToFile(info.getallPlayers());
               System.exit(0);
            }
            catch( IOException except ) {
               
               System.out.println("could not write to the file");
            }
            
         }
         
      }
      
   }
}